set(RESOLV_WRAPPER_LIBRARY /data/data/cc.lycstar.sparrow/files/usr/lib/libresolv_wrapper.so)
