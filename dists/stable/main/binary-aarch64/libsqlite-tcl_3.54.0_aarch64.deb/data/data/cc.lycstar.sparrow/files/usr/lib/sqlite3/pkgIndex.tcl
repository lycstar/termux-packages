# -*- tcl -*-
# Tcl package index file, version ???
#
package ifneeded sqlite3 3.54.0 \
    [list load [file join $dir libsqlite3.54.0.so] Sqlite3]

