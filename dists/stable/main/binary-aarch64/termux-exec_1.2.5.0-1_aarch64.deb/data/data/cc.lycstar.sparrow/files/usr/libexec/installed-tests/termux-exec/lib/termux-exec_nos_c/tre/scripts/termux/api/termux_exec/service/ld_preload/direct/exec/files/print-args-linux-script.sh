#!/data/data/cc.lycstar.sparrow/files/usr/bin/sh

echo "$@"
